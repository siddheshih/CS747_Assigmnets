To Run the code and generate the plots

Run the commnad:

   python gwl.py

This will generate data for Baseline Gridworld,Gridworld with 8 moves, and stochatic winds and save the plots 
as well all the combined plots in the same directory. This will also egenarted and save combined plot for 
sarsa, expected sarsa, Q-Learning and save it in the same directory.
The Baseline plot is saved as Baseline_windy_gridworld.png
The plot with king's moves is saved as Kings_moves.png
The plot with king's moves with stochatic wind is saved as Kings_moves_stochatic.png
The combined plot for above 3  is saved as 	Baseline_kings_stocastic.png
The combined plot for sarsa, expected sarsa and Q-Learning is saved as Sarsa_expectedsarsa_QL.png

The plot for epsilon =0.8 and 0.5 can be obtained by changing the value of epsilon in the code and running it 	
